package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// News Crimson & Bangladesh Emerald Theme
val NewsRedPrimary = Color(0xFFC62828)
val NewsRedDark = Color(0xFF8E0000)
val NewsRedLight = Color(0xFFFF5F52)
val NewsRedContainer = Color(0xFFFFEBEE)
val NewsOnRedContainer = Color(0xFF5C0008)

val NewsGreenSecondary = Color(0xFF00695C)
val NewsGreenContainer = Color(0xFFE0F2F1)
val NewsOnGreenContainer = Color(0xFF00382E)

val NewsAmberAccent = Color(0xFFE65100)

val SurfaceLight = Color(0xFFF9F9FB)
val BackgroundLight = Color(0xFFFFFFFF)
val TextPrimaryLight = Color(0xFF1E232A)
val TextSecondaryLight = Color(0xFF5F6875)

val SurfaceDark = Color(0xFF1E1E24)
val BackgroundDark = Color(0xFF121214)
val TextPrimaryDark = Color(0xFFF0F0F3)
val TextSecondaryDark = Color(0xFFA5ACB8)
